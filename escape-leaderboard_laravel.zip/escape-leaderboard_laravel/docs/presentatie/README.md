# Presentatie

Deze map bevat slides, demo-instructies en opname-links voor het presenteren van het project.

## Acties

-   [ ] Voeg slides toe (PowerPoint/Markdown)
-   [ ] Voeg demo-instructies toe in `docs/presentatie/demo.md`
-   [ ] Voeg opname- of livestream-links toe
