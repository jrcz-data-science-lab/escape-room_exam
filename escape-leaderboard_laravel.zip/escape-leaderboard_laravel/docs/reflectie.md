# Reflectieverslag

## Doel

Evalueer je eigen werk en het teamproces. Beschrijf wat goed ging, wat beter kan en concrete acties.

## Structuur

1. Samenvatting van werkzaamheden
2. Wat ging goed
3. Wat kon beter
4. Drie concrete verbeterpunten en acties
5. Persoonlijke leerdoelen

## Acties

-   [ ] Vul reflectie in na oplevering van MVP
-   [ ] Noem minimaal 3 verbeterpunten met een actieplan
