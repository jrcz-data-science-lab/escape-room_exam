# Changelog

Alle belangrijke wijzigingen en releases worden hier bijgehouden.

## Unreleased

-   Initial project scaffolding
-   Tests and docs added

## Acties

-   [ ] Voeg entries toe per feature/fix bij merge of release
